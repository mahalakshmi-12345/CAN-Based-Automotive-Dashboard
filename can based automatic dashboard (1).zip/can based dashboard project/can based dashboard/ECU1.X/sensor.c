
#include "sensor.h"
#include "adc.h"
#include "can.h"
#include "MSG_ID.h"
#include "uart.h"


uint16_t get_rpm()
{
    // Step 1: Read ADC and convert to speed
    unsigned short int speed;
    speed = (unsigned short)(read_adc(CHANNEL4) / 10.33);

    // Step 2: Calculate RPM
    unsigned int rpm = speed * 60;

    // Step 3: Convert RPM to ASCII string (max 4 digits)
    rpm_str[0] = (rpm / 1000) + '0';            // Thousands
    rpm_str[1] = ((rpm / 100) % 10) + '0';      // Hundreds
    rpm_str[2] = ((rpm / 10) % 10) + '0';       // Tens
    rpm_str[3] = (rpm % 10) + '0';              // Ones
    rpm_str[4] = '\0';                          // Null terminator

    // Step 4: Send over UART
    puts("RPM: ");
    puts(rpm_str);
    puts("\n\r");
    return rpm;
}

/*uint16_t get_engine_temp()
{
    //Implement the engine temperature function
}*/
unsigned pre_key = 0x0F;
IndicatorStatus process_indicator()
{
    //Implement the indicator function
    unsigned char key = read_digital_keypad(STATE_CHANGE);
    if (key != 0x0f)
    {
        pre_key = key;
    }

    if (pre_key == SWITCH1)  // Left indicator
    {
        return e_ind_left;
    }
    else if (pre_key == SWITCH3)  // Right indicator
    {
        return e_ind_right;
    }
    else if (pre_key == SWITCH2)  // Turn off all indicators
    {
        return e_ind_off;
    }
    
    
}
