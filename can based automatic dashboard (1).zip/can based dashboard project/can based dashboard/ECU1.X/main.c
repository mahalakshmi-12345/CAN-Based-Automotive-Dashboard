#define _XTAL_FREQ 20000000             // Define crystal frequency for delay functions

#include "sensor.h"                // Include sensor-related functions like get_rpm and process_indicator
#include "adc.h"                        // Include ADC functions
#include "can.h"                        // Include CAN functions
#include "MSG_ID.h"                     // Include CAN message IDs
#include "uart.h"                       // Include UART functions

// Function to initialize all peripherals
void init_config(void) 
{
    TRISB = 0x3c;                       // Set RB2?RB5 as inputs, others as outputs
    PORTB = 0x3c;                       // Initialize PORTB with 0x3C
    init_adc();                         // Initialize ADC
    init_uart();                        // Initialize UART for debugging
    init_can();                         // Initialize CAN communication
    init_digital_keypad();             // Initialize digital keypad for indicator inputs
}

int main() 
{
    init_config();                      // Call peripheral initialization

    while (1) 
    {                         // Infinite loop
        unsigned int rpm = get_rpm();   // Get current RPM from sensor
        can_transmit(RPM_MSG_ID, rpm_str, 4);  // Transmit RPM over CAN (4-byte string)
        __delay_ms(100);                // Delay for stability

        IndicatorStatus key = process_indicator();  // Read indicator switch status
        static int flag1;                        // Store current indicator status

        if (key == e_ind_left) 
        {
            flag1 = 1;                           // Left indicator ON
        } else if (key == e_ind_right) 
        {
            flag1 = 2;                           // Right indicator ON
        } else if (key == e_ind_off) 
        {
            flag1 = 0;                           // Indicators OFF
        }

        if (flag1 == 1) 
        {
            LEFT_IND_ON();                       // Turn on left indicator
            RIGHT_IND_OFF();                     // Turn off right indicator
        }
        else if (flag1 == 0) 
        {
            LEFT_IND_OFF();                      // Turn off both indicators
            RIGHT_IND_OFF();
        }
        else if (flag1 == 2) 
        {    
            RIGHT_IND_ON();                      // Turn on right indicator
            LEFT_IND_OFF();                      // Turn off left indicator
        }

        can_transmit(INDICATOR_MSG_ID, &flag1, 1);  // Transmit indicator status over CAN
        __delay_ms(100);                            // Delay before next iteration
    }
}
